create definer = root@localhost trigger update_medication_stock_after_insert
    after insert
    on order_items
    for each row
BEGIN
    UPDATE medication
    SET stock_quantity = stock_quantity - NEW.quantity
    WHERE id = NEW.medication_id;
END;

